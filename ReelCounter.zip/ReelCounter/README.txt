REEL COUNTER (Android)

1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > choose this ReelCounter folder. Let Gradle sync finish.
3. Plug in your phone (Developer options + USB debugging on) and press Run,
   or Build > Build APK(s) and send the APK to your phone.
4. Open the app > "Open Accessibility settings" > Reel Counter > turn on.
5. Open Instagram: the circle shows top right and counts each Reel swipe.
6. Long-press home screen > Widgets > Reel Counter.

If counting stops after an Instagram update, edit reelIds in ReelsService.kt.
