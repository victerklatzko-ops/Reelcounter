package com.example.reelcounter

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class CountWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, mgr, it) }
    }

    companion object {
        private fun render(c: Context, mgr: AppWidgetManager, id: Int) {
            val v = RemoteViews(c.packageName, R.layout.widget_count)
            v.setInt(R.id.bg, "setColorFilter", Store.circleColor(c))
            v.setTextViewText(R.id.count, Store.today(c).toString())
            v.setTextViewText(R.id.week, "week ${Store.week(c)}")
            v.setTextColor(R.id.count, Store.textColor(c))
            v.setTextColor(R.id.week, Store.textColor(c))
            val open = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.root, open)
            mgr.updateAppWidget(id, v)
        }

        fun updateAll(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            mgr.getAppWidgetIds(ComponentName(c, CountWidget::class.java)).forEach { render(c, mgr, it) }
        }
    }
}
