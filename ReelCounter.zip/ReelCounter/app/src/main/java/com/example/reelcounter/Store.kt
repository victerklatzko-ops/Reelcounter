package com.example.reelcounter

import android.content.Context
import android.graphics.Color
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Counts are stored per calendar day, so "today" resets automatically at midnight. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("reels", Context.MODE_PRIVATE)

    private fun cal(daysAgo: Int) = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }
    private fun key(daysAgo: Int) = "d_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal(daysAgo).time)

    fun label(daysAgo: Int): String = SimpleDateFormat("EEE d", Locale.getDefault()).format(cal(daysAgo).time)
    fun count(c: Context, daysAgo: Int) = p(c).getInt(key(daysAgo), 0)
    fun today(c: Context) = count(c, 0)
    fun week(c: Context) = (0..6).sumOf { count(c, it) }

    fun increment(c: Context) {
        val k = key(0)
        p(c).edit().putInt(k, p(c).getInt(k, 0) + 1).apply()
    }

    fun circleColor(c: Context) = p(c).getInt("circle", Color.parseColor("#E1306C"))
    fun textColor(c: Context) = p(c).getInt("text", Color.WHITE)
    fun setCircleColor(c: Context, v: Int) = p(c).edit().putInt("circle", v).apply()
    fun setTextColor(c: Context, v: Int) = p(c).edit().putInt("text", v).apply()

    // ---- Reel limit / blocking ----
    fun limit(c: Context) = p(c).getInt("limit", 0)            // 0 = off
    fun setLimit(c: Context, v: Int) = p(c).edit().putInt("limit", v).apply()
    fun blockHour(c: Context) = p(c).getBoolean("blockHour", true)
    fun setBlockHour(c: Context, v: Boolean) = p(c).edit().putBoolean("blockHour", v).apply()
    fun blockUntil(c: Context) = p(c).getLong("until", 0L)
    fun isBlocked(c: Context) = System.currentTimeMillis() < blockUntil(c)

    private fun baseKey() = "b_" + key(0)
    /** Reels watched since the last block (or since midnight). */
    fun used(c: Context) = today(c) - p(c).getInt(baseKey(), 0)

    /** Call after each counted reel. Returns true if the limit was just reached and a block started. */
    fun checkTrigger(c: Context): Boolean {
        val lim = limit(c)
        if (lim <= 0 || isBlocked(c) || used(c) < lim) return false
        val until = if (blockHour(c)) System.currentTimeMillis() + 3_600_000L
        else Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        // base = today's count, so after a 1 hour block you get a fresh allowance
        p(c).edit().putLong("until", until).putInt(baseKey(), today(c)).apply()
        return true
    }
}
