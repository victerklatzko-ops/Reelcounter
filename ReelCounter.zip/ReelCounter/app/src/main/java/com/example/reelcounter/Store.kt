package com.example.reelcounter

import android.content.Context
import android.graphics.Color
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** Counts are stored per calendar day, so "today" resets automatically at midnight. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("reels", Context.MODE_PRIVATE)

    private fun cal(daysAgo: Int) = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }
    private fun key(daysAgo: Int) = "d_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal(daysAgo).time)

    fun label(daysAgo: Int): String = SimpleDateFormat("EEE d", Locale.getDefault()).format(cal(daysAgo).time)
    fun count(c: Context, daysAgo: Int) = p(c).getInt(key(daysAgo), 0)
    fun today(c: Context) = count(c, 0)
    fun week(c: Context) = (0..6).sumOf { count(c, it) }

    fun increment(c: Context) {
        val k = key(0)
        p(c).edit().putInt(k, p(c).getInt(k, 0) + 1).apply()
    }

    fun circleColor(c: Context) = p(c).getInt("circle", Color.parseColor("#E1306C"))
    fun textColor(c: Context) = p(c).getInt("text", Color.WHITE)
    fun setCircleColor(c: Context, v: Int) = p(c).edit().putInt("circle", v).apply()
    fun setTextColor(c: Context, v: Int) = p(c).edit().putInt("text", v).apply()
}
