package com.example.reelcounter

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class ReelsService : AccessibilityService() {

    private val IG = "com.instagram.android"
    // Instagram's Reels pager view ids. Instagram can rename these in updates;
    // if counting stops working, add the new id here.
    private val reelIds = listOf(
        "$IG:id/clips_viewer_view_pager",
        "$IG:id/clips_viewer_root"
    )

    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var last = 0L
    private var style = Triple(-1, 0, 0)

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hide()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == IG) {
            show()
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && onReels()) {
                val now = SystemClock.elapsedRealtime()
                if (now - last > 700) {           // one swipe = one count
                    last = now
                    Store.increment(this)
                    show()
                    CountWidget.updateAll(this)
                }
            }
        } else if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            pkg != "com.android.systemui" && !pkg.contains("inputmethod")
        ) {
            hide()
        }
    }

    private fun onReels(): Boolean {
        val root = rootInActiveWindow ?: return false
        return reelIds.any { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun show() {
        val w = wm ?: return
        val v = bubble ?: TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        }.also {
            bubble = it
            val lp = WindowManager.LayoutParams(
                dp(52), dp(52),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(12)
                y = dp(64)
            }
            w.addView(it, lp)
        }
        val n = Store.today(this)
        val bg = Store.circleColor(this)
        val fg = Store.textColor(this)
        if (style != Triple(n, bg, fg)) {
            style = Triple(n, bg, fg)
            v.text = n.toString()
            v.setTextColor(fg)
            (v.background as GradientDrawable).setColor(bg)
        }
    }

    private fun hide() {
        bubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        bubble = null
        style = Triple(-1, 0, 0)
    }
}
