package com.example.reelcounter

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReelsService : AccessibilityService() {

    private val IG = "com.instagram.android"
    // Instagram's Reels pager view ids. Instagram can rename these in updates;
    // if counting stops working, add the new id here.
    private val reelIds = listOf(
        "$IG:id/clips_viewer_view_pager",
        "$IG:id/clips_viewer_root"
    )

    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var lastScroll = 0L
    private var lastToast = 0L
    private var style = Triple(-1, 0, 0)

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hide()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        // Ignore events from our own bubble, otherwise adding it triggers hide() and it flashes.
        if (pkg == packageName) return
        if (pkg == IG) {
            if (Store.isBlocked(this)) { kick(); return }
            show()
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && onReels()) {
                val now = SystemClock.elapsedRealtime()
                // One swipe fires a burst of scroll events. Count only the first event
                // of a burst, i.e. when things were quiet for a moment before it.
                if (now - lastScroll > 600) {
                    Store.increment(this)
                    show()
                    CountWidget.updateAll(this)
                    if (Store.checkTrigger(this)) { kick(); return }
                }
                lastScroll = now
            }
        } else if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            pkg != "com.android.systemui" && !pkg.contains("inputmethod")
        ) {
            hide()
        }
    }

    /** Send the user to the home screen and tell them when Instagram unlocks. */
    private fun kick() {
        hide()
        performGlobalAction(GLOBAL_ACTION_HOME)
        val now = SystemClock.elapsedRealtime()
        if (now - lastToast > 3000) {
            lastToast = now
            val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(Store.blockUntil(this)))
            Toast.makeText(this, "Reel limit reached. Instagram unlocks at $t", Toast.LENGTH_LONG).show()
        }
    }

    private fun onReels(): Boolean {
        val root = rootInActiveWindow ?: return false
        return reelIds.any { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun show() {
        val w = wm ?: return
        val v = bubble ?: TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        }.also {
            bubble = it
            val lp = WindowManager.LayoutParams(
                dp(52), dp(52),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dp(12)
                y = dp(64)
            }
            w.addView(it, lp)
        }
        val n = Store.today(this)
        val bg = Store.circleColor(this)
        val fg = Store.textColor(this)
        if (style != Triple(n, bg, fg)) {
            style = Triple(n, bg, fg)
            v.text = n.toString()
            v.setTextColor(fg)
            (v.background as GradientDrawable).setColor(bg)
        }
    }

    private fun hide() {
        bubble?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        bubble = null
        style = Triple(-1, 0, 0)
    }
}
