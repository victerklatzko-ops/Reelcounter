package com.example.reelcounter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val colors = listOf("#E1306C", "#E53935", "#FB8C00", "#FDD835", "#43A047", "#1E88E5", "#000000", "#FFFFFF")
        .map { Color.parseColor(it) }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun oval(fill: Int, stroke: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        setStroke(dp(2), stroke)
    }

    private fun serviceOn(): Boolean =
        Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true

    private fun build() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(44), dp(20), dp(24))
        }
        fun label(s: String, size: Float = 16f, bold: Boolean = false) =
            TextView(this).apply {
                text = s; textSize = size
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, dp(4))
                col.addView(this)
            }

        label("Reel Counter", 28f, true)

        TextView(this).apply {
            text = Store.today(this@MainActivity).toString()
            textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Store.textColor(this@MainActivity))
            background = oval(Store.circleColor(this@MainActivity), Color.TRANSPARENT)
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply { topMargin = dp(12); bottomMargin = dp(4) }
            col.addView(this)
        }
        label("Today (resets at midnight)")
        label("This week: ${Store.week(this)} reels", 20f, true)

        if (!serviceOn()) {
            label("Step 1: turn on the counter. Find \"Reel Counter\" under Installed/Downloaded apps and switch it on.")
            Button(this).apply {
                text = "Open Accessibility settings"
                setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                col.addView(this)
            }
        } else {
            label("Counter is ON. Open Instagram and the circle appears top right.")
        }

        label("Circle color", 16f, true)
        swatches(col, Store.circleColor(this)) { Store.setCircleColor(this, it); CountWidget.updateAll(this); build() }
        label("Number color", 16f, true)
        swatches(col, Store.textColor(this)) { Store.setTextColor(this, it); CountWidget.updateAll(this); build() }

        label("Reel limit", 16f, true)
        val lim = Store.limit(this)
        val limRow = LinearLayout(this)
        listOf(0, 50, 100, 200, 300, 450).forEach { v ->
            limRow.addView(Button(this).apply {
                text = if (v == 0) "Off" else v.toString()
                isAllCaps = false
                alpha = if (v == lim) 1f else 0.4f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { Store.setLimit(this@MainActivity, v); build() }
            })
        }
        col.addView(limRow)
        label("When the limit is reached, block Instagram for:")
        val modeRow = LinearLayout(this)
        listOf(true to "1 hour", false to "Rest of day").forEach { (hour, name) ->
            modeRow.addView(Button(this).apply {
                text = name
                isAllCaps = false
                alpha = if (Store.blockHour(this@MainActivity) == hour) 1f else 0.4f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { Store.setBlockHour(this@MainActivity, hour); build() }
            })
        }
        col.addView(modeRow)
        if (Store.isBlocked(this)) {
            val t = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(Store.blockUntil(this)))
            label("Instagram is blocked until $t", 15f, true)
        } else if (lim > 0) {
            label("${maxOf(lim - Store.used(this), 0)} reels left before the block", 15f)
        }

        label("Last 7 days", 16f, true)
        for (i in 0..6) label("${Store.label(i)}:  ${Store.count(this, i)}", 15f)

        label("Widget: long-press your home screen, choose Widgets, then Reel Counter. Lock screen widgets only work on phones that support them (e.g. Samsung, Android 16).", 13f)

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun swatches(col: LinearLayout, current: Int, onPick: (Int) -> Unit) {
        val row = LinearLayout(this)
        colors.forEach { c ->
            row.addView(View(this).apply {
                background = oval(c, if (c == current) Color.parseColor("#FF4081") else Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(dp(32), dp(32)).apply { rightMargin = dp(6) }
                setOnClickListener { onPick(c) }
            })
        }
        col.addView(row)
    }
}
